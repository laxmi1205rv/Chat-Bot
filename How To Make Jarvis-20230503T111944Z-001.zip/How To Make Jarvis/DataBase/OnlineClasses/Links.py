
def Science():

    Link = "https://meet.google.com/ify-fhhk-zrs"

    return Link

def Maths():

    Link = "https://meet.google.com/ify-fhhk-zrs"

    return Link

def Hindi():

    Link = "https://meet.google.com/ify-fhhk-zrs"

    return Link

def English():

    Link = "https://meet.google.com/ify-fhhk-zrs"

    return Link

def sst():

    Link = "https://meet.google.com/ify-fhhk-zrs"

    return Link

